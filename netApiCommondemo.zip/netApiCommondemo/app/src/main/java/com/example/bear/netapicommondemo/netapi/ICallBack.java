package com.example.bear.netapicommondemo.netapi;

public interface ICallBack {
    void onSuccess(String result);
    void onError(String error);
}
