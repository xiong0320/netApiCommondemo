package com.example.bear.netapicommondemo;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.bear.netapicommondemo.netapi.HttpCallback;
import com.example.bear.netapicommondemo.netapi.HttpHelper;
import com.example.bear.netapicommondemo.netapi.ResponseClass;

import java.util.HashMap;




public class MainActivity extends AppCompatActivity {

    private static final String url = "https://www.baidu.com";
    private static final String[] permissionS ={Manifest.permission.ACCESS_NETWORK_STATE,Manifest.permission.INTERNET};
    private Handler mHandler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        requestPermission();
        findViewById(R.id.btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                postDemo();
            }
        });

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void requestPermission() {
        if (ContextCompat.checkSelfPermission(this,permissionS[0])!= PackageManager.PERMISSION_GRANTED) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(permissionS,1);
            }
        }

    }

    private void postDemo(){
        HashMap<String,Object> params = new HashMap<>();
        params.put("key",1);
        HttpHelper.getInstance().post(url, params, new HttpCallback<String>() {
            @Override
            public void onSuccess(String s) {
                mHandler.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MainActivity.this,"code " +s,Toast.LENGTH_LONG).show();
                    }
                });

            }
        });
    }
}
